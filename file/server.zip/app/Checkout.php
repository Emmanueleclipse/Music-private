<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Checkout extends Model
{
    public function user()
    {

        return $this->belongsTo(User::class, 'user_id', 'id');

    }
    public function buyer()
    {

        return $this->belongsTo(User::class, 'buyer_id', 'id');

    }
    public function track()
    {

        return $this->belongsTo(Track::class, 'track_id', 'id');

    }
}
