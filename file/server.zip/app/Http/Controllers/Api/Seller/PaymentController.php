<?php

namespace App\Http\Controllers\Api\Seller;

use App\Http\Controllers\Controller;
use App\Services\Stripe\Customer;
use App\Services\Stripe\Seller;
use App\User;
use Auth;
use Illuminate\Http\Request;
use Stripe\Stripe;
use Validator;

class PaymentController extends Controller
{

    /**
     * Redirect to Stripe To Create Account
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function create()
    {
        $url = config('services.stripe.connect');
        return $url;
    }
    /**
     * Check stripe user connect id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function checkStripeUser(Request $request)
    {
        $user = Auth::user();
        if ($request->has('code') && $request->code != '') {

            try {
                $data = Seller::create($request->code);
                $user = User::where('id', Auth::user()->id)->first();
                $user->stripe_connect_id = $data->stripe_user_id;
                $user->save();

                return response()->json([
                    'success' => true,
                ], 200);
            } catch (\Exception $e) {
                return response()->json([
                    'success' => false,
                    'error' => 'Authorization code does not exist',
                ], 200);

            }
        }
        if (!is_null($user->stripe_connect_id)) {
            return response()->json([
                'success' => true,
            ], 200);
        }
        return response()->json([
            'success' => false,
        ], 200);
    }

    /**
     * Stripe Updgrate account
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function upgradeaccount(Request $request)
    {
        if (Auth::check() && auth()->user()->stripe_customer_id == null) {
            $rules = array(
                'card_number' => 'required',
                'card_name' => 'required',
                'mmyy' => 'required',
                'cvc' => 'required',
            );
            $validator = Validator::make($request->card, $rules);
            if (!$validator->fails()) {
                try {
                    $explode = explode('/', $request->card['mmyy']);
                    $month = $explode[0];
                    $year = $explode[1];
                    $card = [
                        'card' => [
                            'number' => $request->card['card_number'],
                            'exp_month' => $month,
                            'exp_year' => $year,
                            'cvc' => $request->card['cvc'],
                        ],
                    ];
                    Stripe::setApiKey(config('services.stripe.secret'));
                    $user = Auth::user();

                    $customer_id = Customer::save($user, $card);
                    $user->update(['is_premium' => 1, 'is_premium_date' => \Carbon\Carbon::now()->addYear()]);
                    // $charge = Charge::create([
                    //     'amount' => 89.99,
                    //     'currency' => 'usd',
                    //     'customer' => $customer_id,
                    //     'description' => $user->name,
                    // ]);

                    return response()->json([
                        'success' => true,
                    ], 200);

                } catch (\Exception $e) {
                    return response()->json([
                        'success' => false,
                        'error' => $e->getMessage(),
                    ], 422);
                }

            }
            return response()->json([
                'success' => false,
                'errors' => $validator->errors(),
            ], 422);
        } else {
            Stripe::setApiKey(config('services.stripe.secret'));
            $user = Auth::user();

            $customer_id = $user->stripe_customer_id;

            $charge = Charge::create([
                'amount' => 89.99,
                'currency' => 'usd',
                'customer' => $customer_id,
                'description' => $user->name,
            ]);
            $user->update(['is_premium' => 1, 'is_premium_date' => \Carbon\Carbon::now()->addYear()]);
            return response()->json([
                'success' => true,
            ], 200);
        }

    }

    public function upgradeaccountwithoutcard(Request $request)
    {
        try {
            $user = Auth::user();
            Stripe::setApiKey(config('services.stripe.secret'));

            return response()->json([
                'success' => true,
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => $e->getMessage(),
            ], 422);
        }

    }
}
