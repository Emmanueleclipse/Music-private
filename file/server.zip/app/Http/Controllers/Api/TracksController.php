<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Track;
use Illuminate\Http\Request;

class TracksController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $tracks = Track::with('user', 'genre')->orderBy('created_at', 'DESC')->paginate(15);

        return response()->json([
            'success' => true,
            'datas' => $tracks,
        ], 200);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function Search(Request $request)
    {
        $term = $request->q;
        if ($term) {
            $tracks = Track::with('user', 'genre')
                ->Where('title', 'LIKE', '%' . $term . '%')
                ->orWhere('bpm', 'LIKE', '%' . $term . '%')
                ->orWhereHas('genre', function ($query) use ($term) {
                    $query->where('name', 'LIKE', "%$term%");
                })
                ->orWhereHas('user', function ($query) use ($term) {
                    $query->where('name', 'LIKE', "%$term%");
                    $query->orWhere('producer_name', 'LIKE', "%$term%");
                })
                ->orderBy('created_at', 'DESC')
                ->paginate(12);

            return response()->json([
                'success' => true,
                'datas' => $tracks,
            ], 200);
        }

        return response()->json([
            'success' => false,
        ], 404);

    }

}
