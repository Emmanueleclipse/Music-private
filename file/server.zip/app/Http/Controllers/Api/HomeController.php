<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Track;

class HomeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function latestTrack()
    {
        $datas = Track::with(['user', 'genre'])->latest()->take(10)->get();
        return response()->json([
            'success' => true,
            'datas' => $datas,
        ], 200);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function TopinGenres()
    {
        $datas = Track::with(['user', 'genre'])->latest()->take(10)->get();
        return response()->json([
            'success' => true,
            'datas' => $datas,
        ], 200);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function featureTrack()
    {
        $datas = Track::with(['user', 'genre'])->inRandomOrder()->limit(10)->get();
        return response()->json([
            'success' => true,
            'datas' => $datas,
        ], 200);
    }

}
