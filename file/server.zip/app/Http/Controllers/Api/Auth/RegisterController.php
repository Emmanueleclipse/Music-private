<?php

namespace App\Http\Controllers\Api\Auth;

use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Intervention\Image\Facades\Image;
use Tymon\JWTAuth\JWTAuth;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
     */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = '';

    protected $auth;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(JWTAuth $auth)
    {
        $this->auth = $auth;
    }

    /**
     * Handle a registration request for the application.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function register(Request $request)
    {
        $data = json_decode($request->data, true);

        $rules = array(
            'name' => 'required',
            'email' => 'required|email|unique:users,email',
            'password' => 'required', 'min:8', 'confirmed',
            'producer_name' => 'required',
            'invite_code' => 'required',
        );
        $validator = Validator::make($data, $rules);

        if (!$validator->fails()) {

            $user = new User();
            $user->name = $data['name'];
            $user->email = $data['email'];
            $user->producer_name = $data['producer_name'];
            $user->invite_code = $data['invite_code'];
            $user->location = $data['location'];
            $user->bio = $data['bio'];
            $user->paypal = $data['paypal'];
            $user->password = Hash::make($data['password']);
            $name = null;
            if ($request->has('photo') && $request->photo != 'null') {
                $img = $request->file('photo');
                $random = Str::random('20') . time();
                $name = $random . '.' . $img->getClientOriginalExtension();
                $image = Image::make($img);
                $image->save('uploads/users/' . $name, 60);
            }

            if ($name) {
                $user->images = 'uploads/users/' . $name;
            }
            $user->save();
            $token = $this->auth->attempt($request->only('email', 'password'));

            return response()->json([
                'success' => true,
                'id' => $user->id,
            ], 200);
        }

        return response()->json([
            'success' => false,
            'errors' => $validator->errors(),
        ], 422);
    }
    public function registertype(Request $request)
    {
        $user = User::where('id', $request->id)->first();
        $user->type = $request->type;
        $user->save();
        $token = $this->auth->attempt($request->only('email', 'password'));
        return response()->json([
            'success' => true,
            'data' => $user,
            'token' => $token,
        ], 200);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\Models\User
     */
    protected function create(array $data)
    {
        return User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => Hash::make($data['password']),
        ]);
    }
}
