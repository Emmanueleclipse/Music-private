<?php

namespace App\Http\Controllers\Api;

use App\Checkout;
use App\Http\Controllers\Controller;
use App\Mail\getOrderMail;
use App\Mail\sendOrderMail;
use App\Services\Stripe\Customer;
use App\User;
use Auth;
use Illuminate\Http\Request;
use Mail;
use Stripe\Charge;
use Stripe\Stripe;
use Stripe\Transfer;
use Validator;

class CheckOutController extends Controller
{
    public function checkout(Request $request)
    {
        $rules = array(
            'card_number' => 'required',
            'card_name' => 'required',
            'mmyy' => 'required',
            'cvc' => 'required',
        );
        $validator = Validator::make($request->card, $rules);
        if (!$validator->fails()) {
            try {

                $explode = explode('/', $request->card['mmyy']);
                $month = $explode[0];
                $year = $explode[1];
                $card = [
                    'card' => [
                        'number' => $request->card['card_number'],
                        'exp_month' => $month,
                        'exp_year' => $year,
                        'cvc' => $request->card['cvc'],
                    ],
                ];
                $user = Auth::user();
                $customer_id = Customer::save($user, $card);
                $cartdatas = $request->cart_info;
                foreach ($cartdatas as $data) {
                    Stripe::setApiKey(config('services.stripe.secret'));

                    $charge = Charge::create([
                        'amount' => 0,
                        'currency' => 'usd',
                        'customer' => $customer_id,
                        'description' => $data['name'],
                    ]);
                    Transfer::create([
                        'amount' => $data['total'],
                        "currency" => "usd",
                        "source_transaction" => $charge->id,
                        'destination' => $data['user']['stripe_connect_id'],
                    ]);

                    $checkout = new Checkout();
                    $checkout->amount = $data['total'];
                    $checkout->user_id = $data['user']['id'];
                    $checkout->buyer_id = Auth::user()->id;
                    $checkout->track_id = $data['id'];
                    $checkout->save();

                    $seller = User::where('id', $data['user']['id'])->first();

                    $data = ['name' => $seller->name, 'data' => $data, 'buyer' => auth()->user(), 'title' => 'Congrats!  You have one sell you beats'];
                    Mail::to($seller->email)->send(new getOrderMail($data));

                }
                $data = ['name' => Auth::user()->name, 'datas' => $cartdatas, 'title' => 'Your Order Details.'];
                Mail::to(Auth::user()->email)->send(new sendOrderMail($data));

                return response()->json([
                    'success' => true,
                ], 200);

            } catch (\Exception $e) {
                return response()->json([
                    'success' => false,
                    'error' => $e->getMessage(),
                ], 422);
            }

        }
        return response()->json([
            'success' => false,
            'errors' => $validator->errors(),
        ], 422);

    }
    public function checkoutwithoutcard(Request $request)
    {
        try {
            $user = Auth::user();
            $cartdatas = $request->cart_info;
            foreach ($cartdatas as $data) {

                Stripe::setApiKey(config('services.stripe.secret'));

                $charge = Charge::create([
                    'amount' => 0,
                    'currency' => 'usd',
                    'customer' => auth()->user()->stripe_customer_id,
                    'description' => $data['name'],
                ]);
                Transfer::create([
                    'amount' => $data['total'],
                    "currency" => "usd",
                    "source_transaction" => $charge->id,
                    'destination' => $data['user']['stripe_connect_id'],
                ]);

                $checkout = new Checkout();
                $checkout->amount = $data['total'];
                $checkout->user_id = $data['user']['id'];
                $checkout->buyer_id = Auth::user()->id;
                $checkout->track_id = $data['id'];
                $checkout->save();

                $seller = User::where('id', $data['user']['id'])->first();

                $data = ['name' => $seller->name, 'data' => $data, 'buyer' => auth()->user(), 'title' => 'Congrats!  You have one sell you beats'];
                Mail::to($seller->email)->send(new getOrderMail($data));

            }
            $data = ['name' => Auth::user()->name, 'datas' => $cartdatas, 'title' => 'Your Order Details.'];
            Mail::to(Auth::user()->email)->send(new sendOrderMail($data));

            return response()->json([
                'success' => true,
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => $e->getMessage(),
            ], 422);
        }

    }
}
