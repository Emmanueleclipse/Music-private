<?php

namespace App\Http\Controllers\Api\Seller;

use App\Helpers\General\CollectionHelper;
use App\Http\Controllers\Controller;
use App\Track;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

class TracksController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (auth()->check()) {
            if (auth()->user()->is_premium() == 'true') {
                $tracks = Track::where('user_id', auth()->user()->id)->orderBy('created_at', 'DESC')->paginate(10);
            } else {
                $tracks = Track::where('user_id', auth()->user()->id)->latest()->limit(15)->get();
                $collection = collect($tracks);
                $total = $collection->count();
                $pageSize = 10;
                $tracks = CollectionHelper::paginate($collection, $total, $pageSize);
            }

            return response()->json([
                'success' => true,
                'datas' => $tracks,
            ], 200);
        }

        return response()->json([
            'success' => false,
            'errors' => 'Unauthinticate',
        ], 401);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (auth()->check()) {
            $rules = array(
                'audio_file' => 'required',
                'zip_files' => 'required',
                'feature_image' => 'required',
                'name' => 'required|min:3',
                'genre' => 'required',
                'date' => 'required',
                'bpm' => 'required',
                'basic_price' => 'required|integer',
                'premium_price' => 'integer',
            );
            $validator = Validator::make($request->all(), $rules);

            if (!$validator->fails()) {
                $track = new Track();
                $track->title = $request->name;
                $track->bpm = $request->bpm;
                $track->genre_id = $request->genre;
                $track->basic_price = $request->basic_price;
                $track->premium_price = $request->premium_price;
                $track->date = $request->date;
                $track->user_id = auth()->user()->id;

                $isPremium = auth()->user()->is_premium();
                if ($isPremium == 'true') {
                    $track->save();

                    return response()->json([
                        'success' => true,
                        'id' => $track->id,
                        'data' => $track,
                    ], 200);
                } else {
                    $check = Track::where('user_id', auth()->user()->id)->count();
                    if ($check >= 15) {
                        return response()->json([
                            'success' => false,
                            'error' => 'Free account limit exceeded!',
                        ], 422);
                    } else {
                        $track->save();

                        return response()->json([
                            'success' => true,
                            'id' => $track->id,
                            'data' => $track,
                        ], 200);
                    }
                }

            }

            return response()->json([
                'success' => false,
                'errors' => $validator->errors(),
            ], 422);
        } else {
            return response()->json([
                'success' => false,
                'errors' => 'Unauthinticate',
            ], 401);
        }
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function audio(Request $request, $id)
    {
        $storage = Storage::disk('public')->put($id, $request->file);
        $track = Track::find($request->id);
        $track->audio_file = $storage;
        $track->save();
        if ($track) {
            return response()->json([
                'success' => true,
            ], 200);
        }

    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function zip(Request $request, $id)
    {
        $storage = Storage::disk('public')->put($id, $request->file);
        $track = Track::find($request->id);
        $track->deliverable_audio = $storage;
        $track->save();
        if ($track) {
            return response()->json([
                'success' => true,
            ], 200);
        }
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function img(Request $request, $id)
    {
        $storage = Storage::put($id, $request->file);
        $track = Track::find($request->id);
        $track->image = $storage;
        $track->save();
        if ($track) {
            return response()->json([
                'success' => true,
            ], 200);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {

        $track = Track::find($id);

        if ($track) {

            Storage::delete($track->audio_file);
            Storage::delete($track->deliverable_audio);
            Storage::delete($track->image);
            $track->delete();
            return response()->json([
                'success' => true,
            ], 200);
        }

    }
}
