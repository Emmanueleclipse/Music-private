<?php

namespace App\Http\Controllers\Api\Seller;

use App\Checkout;
use App\Http\Controllers\Controller;

class DashboardController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (auth()->check() && auth()->user()->is_admin === 0 && auth()->user()->type === 0) {

            $payments = Checkout::with('buyer', 'track')->where('user_id', auth()->user()->id)->latest()->paginate(10);

            $total_earnings = $items_sold = $item_per_order = '';

            $total_earnings = Checkout::where('user_id', auth()->user()->id)->sum('amount');
            $items_sold = Checkout::where('user_id', auth()->user()->id)->count();

            $item_per_orders = Checkout::where('user_id', auth()->user()->id)->select('track_id')->distinct()->get();
            $items = [];
            foreach ($item_per_orders as $item_per_order) {
                $items[] = Checkout::where('track_id', $item_per_order->track_id)->count();

            }
            $item_per_order = collect($items)->avg();
            return response()->json([
                'success' => true,
                'datas' => $payments,
                'total_earnings' => $this->number_count_format($total_earnings),
                'items_sold' => $items_sold,
                'item_per_order' => $item_per_order,
            ], 200);

        }

        return response()->json([
            'success' => false,
            'errors' => 'Unauthinticate or Unauthorized',
        ], 401);
    }
}
