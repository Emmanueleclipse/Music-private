<?php

namespace App\Http\Controllers\Api;

use App\Genre;
use App\Http\Controllers\Controller;
use App\Track;
use App\User;
use Auth;

class HomeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function latestTrack()
    {
        $users = User::where('is_admin', 0)->get();
        $data = [];
        foreach ($users as $user) {
            if ($user->is_premium() == 'true') {
                $data[] = $user->tracks;
            } else {
                $data[] = $user->tracks()->with('user')->orderBy('created_at', 'desc')->take(15)->get();
            }
        }
        $collection = collect($data);
        $products = $collection->flatten(1);

        $ids = $collection = collect($products->all())->pluck('id');

        $datas = Track::whereIn('id', $ids)->with(['user', 'genre'])->latest()->take(10)->get();
        return response()->json([
            'success' => true,
            'datas' => $datas,
        ], 200);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function TopinGenres()
    {
        $users = User::where('is_admin', 0)->get();
        $data = [];
        foreach ($users as $user) {
            if ($user->is_premium() == 'true') {
                $data[] = $user->tracks;
            } else {
                $data[] = $user->tracks()->with('user')->orderBy('created_at', 'desc')->take(15)->get();
            }
        }
        $collection = collect($data);
        $products = $collection->flatten(1);

        $ids = $collection = collect($products->all())->pluck('id');

        $genre_ids = Genre::withCount('genre_tracks')
            ->latest('genre_tracks_count')
            ->take(2)
            ->with('genre_tracks')
            ->get()->pluck('id');

        $datas = Track::with(['user', 'genre'])->whereIn('genre_id', $genre_ids)->whereIn('id', $ids)->latest()->take(10)->get();
        return response()->json([
            'success' => true,
            'datas' => $datas,
        ], 200);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function featureTrack()
    {
        $users = User::where('is_admin', 0)->get();
        $data = [];
        foreach ($users as $user) {
            if ($user->is_premium() == 'true') {
                $data[] = $user->tracks;
            } else {
                $data[] = $user->tracks()->with('user')->orderBy('created_at', 'desc')->take(15)->get();
            }
        }
        $collection = collect($data);
        $products = $collection->flatten(1);

        $ids = $collection = collect($products->all())->pluck('id');
        $datas = Track::whereIn('id', $ids)->with(['user', 'genre'])->inRandomOrder()->limit(10)->get();
        return response()->json([
            'success' => true,
            'datas' => $datas,
        ], 200);
    }

    public function checkSaveCard()
    {
        $user = Auth::user();
        $customer_id = $user->stripe_customer_id;
        if ($customer_id != null) {
            return response()->json([
                'success' => true,
            ], 200);
        }
        return response()->json([
            'success' => false,
        ], 200);
    }

    public function checkIsPremium()
    {
        $user = Auth::user();
        $premium = $user->is_premium();
        if ($premium == 'false') {
            return response()->json([
                'success' => false,
            ], 200);
        }
        return response()->json([
            'success' => true,
        ], 200);
    }
}
