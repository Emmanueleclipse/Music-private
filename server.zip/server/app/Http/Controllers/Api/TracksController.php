<?php

namespace App\Http\Controllers\Api;

use App\Helpers\General\CollectionHelper;
use App\Http\Controllers\Controller;
use App\Track;
use App\User;
use Illuminate\Http\Request;

class TracksController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $users = User::where('is_admin', 0)->get();
        $data = [];
        foreach ($users as $user) {
            if ($user->is_premium() == 'true') {
                $data[] = $user->tracks;
            } else {
                $data[] = $user->tracks()->with('user')->orderBy('created_at', 'desc')->take(15)->get();
            }
        }
        $collection = collect($data);
        $products = $collection->flatten(1);

        $collection = collect($products->all());
        $total = $collection->count();
        $pageSize = 10;
        $tracks = CollectionHelper::paginate($collection, $total, $pageSize);

        return response()->json([
            'success' => true,
            'datas' => $tracks,
        ], 200);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function Search(Request $request)
    {

        $users = User::where('is_admin', 0)->get();
        $data = [];
        foreach ($users as $user) {
            if ($user->is_premium() == 'true') {
                $data[] = $user->tracks;
            } else {
                $data[] = $user->tracks()->with('user')->orderBy('created_at', 'desc')->take(15)->get();
            }
        }
        $collection = collect($data);
        $products = $collection->flatten(1);

        $ids = $collection = collect($products->all())->pluck('id');

        $term = $request->q;
        if ($term) {
            $tracks = Track::with('user', 'genre')
                ->where(function ($q) use ($term) {
                    $q->orWhere('title', 'LIKE', '%' . $term . '%')
                        ->orWhere('bpm', 'LIKE', '%' . $term . '%')
                        ->orWhereHas('genre', function ($query) use ($term) {
                            $query->where('name', 'LIKE', "%$term%");
                        })
                        ->orWhereHas('user', function ($query) use ($term) {
                            $query->where('name', 'LIKE', "%$term%");
                            $query->orWhere('producer_name', 'LIKE', "%$term%");
                        });
                })->whereIn('id', $ids)->orderBy('created_at', 'DESC')
                ->paginate(10);

            return response()->json([
                'success' => true,
                'datas' => $tracks,
            ], 200);
        }

        return response()->json([
            'success' => false,
        ], 404);

    }

}
