<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Http\Request;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (auth()->check() && auth()->user()->is_admin === 1) {
            $users = User::where('is_admin', 0)->latest()->paginate(10);

            return response()->json([
                'success' => true,
                'datas' => $users,
            ], 200);
        }

        return response()->json([
            'success' => false,
            'errors' => 'Unauthinticate or Unauthorized',
        ], 401);
    }

    public function activeDeactive(Request $request, $id)
    {
        if (auth()->check() && auth()->user()->is_admin === 1) {
            $user = User::where('is_admin', 0)->where('id', $id)->first();
            if ($user->status === 1) {
                $user->update(['status' => 0]);
            } else {
                $user->update(['status' => 1]);
            }
            $users = User::where('is_admin', 0)->latest()->paginate(10);

            return response()->json([
                'success' => true,
                'users' => $users,
            ], 200);
        }

        return response()->json([
            'success' => false,
            'errors' => 'Unauthinticate or Unauthorized',
        ], 401);
    }

    public function destroy($id)
    {

        if (auth()->check() && auth()->user()->is_admin === 1) {
            $user = User::where('is_admin', 0)->where('id', $id)->first();
            if ($user) {
                $image_path = public_path('/') . $user->images;
                if (\File::exists($image_path)) {
                    \File::delete($image_path);
                }
                $user->delete();
            }
            return response()->json([
                'success' => true,
            ], 200);
        }
        return response()->json([
            'success' => false,
            'errors' => 'Unauthinticate or Unauthorized',
        ], 401);
    }
}
