<?php

namespace App\Http\Controllers\Api\Admin;

use App\Checkout;
use App\Http\Controllers\Controller;
use App\Track;
use App\User;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (auth()->check() && auth()->user()->is_admin === 1) {
            $users = User::where('is_admin', 0)->latest()->take(10)->get();
            $transaction = $added_product = $user_count = '';
            $transaction = Checkout::sum('amount');
            $user_count = User::where('is_admin', 0)->count();
            $added_product = Track::count();

            return response()->json([
                'success' => true,
                'datas' => $users,
                'added_product' => $this->number_count_format($added_product),
                'user_count' => $this->number_count_format($user_count),
                'transaction' => $this->number_count_format($transaction),
            ], 200);
        }

        return response()->json([
            'success' => false,
            'errors' => 'Unauthinticate or Unauthorized',
        ], 401);
    }

    public function activeDeactive(Request $request, $id)
    {
        if (auth()->check() && auth()->user()->is_admin === 1) {
            $user = User::where('is_admin', 0)->where('id', $id)->first();
            if ($user->status === 1) {
                $user->update(['status' => 0]);
            } else {
                $user->update(['status' => 1]);
            }
            $users = User::where('is_admin', 0)->latest()->take(10)->get();

            return response()->json([
                'success' => true,
                'users' => $users,
            ], 200);
        }

        return response()->json([
            'success' => false,
            'errors' => 'Unauthinticate or Unauthorized',
        ], 401);
    }

    public function destroy($id)
    {
        if (auth()->check() && auth()->user()->is_admin === 1) {
            $user = User::where('is_admin', 0)->where('id', $id)->first();
            if ($user) {
                $image_path = public_path('/') . $user->images;
                if (\File::exists($image_path)) {
                    \File::delete($image_path);
                }
                $user->delete();
            }
            return response()->json([
                'success' => true,
            ], 200);
        }
        return response()->json([
            'success' => false,
            'errors' => 'Unauthinticate or Unauthorized',
        ], 401);
    }

}
