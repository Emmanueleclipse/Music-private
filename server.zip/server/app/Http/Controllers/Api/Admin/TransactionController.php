<?php

namespace App\Http\Controllers\Api\Admin;

use App\Checkout;
use App\Helpers\General\CollectionHelper;
use App\Http\Controllers\Controller;
use App\User;

class TransactionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $checkouts = Checkout::select('user_id')->distinct()->get();
        $transaction = [];
        foreach ($checkouts as $checkout) {
            $price = Checkout::where('user_id', $checkout->user_id)->sum('amount');
            $user = User::where('id', $checkout->user_id)->first();
            $transaction[] = [
                'user' => $user,
                'amount' => $price,
            ];
        }
        $collection = collect($transaction);
        $total = $collection->count();
        $pageSize = 10;
        $transaction = CollectionHelper::paginate($collection, $total, $pageSize);
        return response()->json([
            'success' => true,
            'datas' => $transaction,
        ], 200);
    }

}
