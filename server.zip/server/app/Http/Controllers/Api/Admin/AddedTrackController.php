<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Track;
use Illuminate\Support\Facades\Storage;

class AddedTrackController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (auth()->check()) {
            $tracks = Track::with('user')->orderBy('created_at', 'DESC')->paginate(10);

            return response()->json([
                'success' => true,
                'datas' => $tracks,
            ], 200);
        }

        return response()->json([
            'success' => false,
            'errors' => 'Unauthinticate',
        ], 401);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $track = Track::find($id);

        if ($track) {

            Storage::delete($track->audio_file);
            Storage::delete($track->deliverable_audio);
            Storage::delete($track->image);
            $track->delete();
            return response()->json([
                'success' => true,
            ], 200);
        }

    }
}
