<?php

namespace App\Http\Controllers\Api\Buyer;

use App\Checkout;
use App\Helpers\General\CollectionHelper;
use App\Http\Controllers\Controller;
use App\Track;

class DashboardController extends Controller
{
    public function index()
    {

        if (auth()->check() && auth()->user()->is_admin === 0 && auth()->user()->type === 1) {

            $items = Checkout::with('user', 'track')->where('buyer_id', auth()->user()->id)->latest()->paginate(10);
            $newData = [];
            foreach ($items as $item) {
                $newData[] = [
                    "track" => Track::with('genre')->where('id', $item->track->id)->first(),
                    "user" => $item->user,
                    "amount" => $item->amount,
                ];
            }
            $collection = collect($newData);
            $total = $collection->count();
            $pageSize = 10;
            $newData = CollectionHelper::paginate($collection, $total, $pageSize);
            return response()->json([
                'success' => true,
                'datas' => $newData,
            ], 200);

        }

        return response()->json([
            'success' => false,
            'errors' => 'Unauthinticate or Unauthorized',
        ], 401);
    }
}
