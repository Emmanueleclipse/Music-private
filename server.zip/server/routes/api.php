<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
 */

Route::group(['prefix' => '/auth', ['middleware' => 'throttle:20,5', 'cors']], function () {
    Route::post('/registers', 'Auth\RegisterController@register');
    Route::post('/register/type', 'Auth\RegisterController@registertype');
    Route::post('/login', 'Auth\LoginController@login');

    Route::get('/login/{service}', 'Auth\SocialLoginController@redirect');
    Route::get('/login/{service}/callback', 'Auth\SocialLoginController@callback');
});

Route::group(['middleware' => 'jwt.auth'], function () {
    Route::get('/me', 'MeController@index');
    Route::get('/auth/logout', 'MeController@logout');

    // start coding for basic route
    Route::get('seller/dashboard', 'Seller\DashboardController@index');
    Route::get('seller/tracks', 'Seller\TracksController@index');
    Route::post('seller/tracks/add-tracks', 'Seller\TracksController@store');
    Route::delete('seller/tracks/delete/{id}', 'Seller\TracksController@destroy');

    Route::get('seller/stripe', 'Seller\PaymentController@create');
    Route::get('seller/stripe-check', 'Seller\PaymentController@checkStripeUser');
    Route::post('upgrade-account', 'Seller\PaymentController@upgradeaccount');
    Route::post('upgrade-account-without-card', 'Seller\PaymentController@upgradeaccountwithoutcard');
    Route::post('paypal-pay', 'Seller\PaymentController@paypalPay');

    /**
     * =================================================
     * start coding for Buyer controller
     */
    Route::get('buyer/dashboard', 'Buyer\DashboardController@index');
    /**
     * =================================================
     * start coding for admin controller
     */
    Route::get('/admin/dashboard', 'Admin\DashboardController@index');
    Route::delete('/admin/user/delete/{id}', 'Admin\DashboardController@destroy');
    Route::post('/admin/user/active-deactive/{id}', 'Admin\DashboardController@activeDeactive');

    Route::get('/admin/transaction', 'Admin\TransactionController@index');

    Route::get('/admin/users', 'Admin\UserController@index');
    Route::delete('/admin/users/delete/{id}', 'Admin\UserController@destroy');
    Route::post('/admin/users/active-deactive/{id}', 'Admin\UserController@activeDeactive');

    Route::get('/admin/tracks', 'Admin\AddedTrackController@index');
    Route::delete('/admin/tracks/delete/{id}', 'Admin\AddedTrackController@destroy');
    //process checkout

    Route::post('checkout', 'CheckOutController@checkout');
    Route::post('checkout-without-card', 'CheckOutController@checkoutwithoutcard');

    Route::get('check-savecard', 'HomeController@checkSaveCard');
    Route::get('check-is-premium', 'HomeController@checkIsPremium');
});

// public route
Route::post('/tracks/upload/audio/{id}', 'Seller\TracksController@audio');
Route::post('/tracks/upload/audio/zip/{id}', 'Seller\TracksController@zip');
Route::post('/tracks/upload/audio/img/{id}', 'Seller\TracksController@img');

Route::get('/tracks', 'TracksController@index');
Route::get('/tracks/search', 'TracksController@Search');

Route::get('/latest-tracks', 'HomeController@latestTrack');
Route::get('/top-genres', 'HomeController@topinGenres');
Route::get('/feature-tracks', 'HomeController@featureTrack');
