<div class="clearfix"></div>
        <!-- Footer -->
        <footer class="site-footer">
            <div class="footer-inner bg-white">
                <div class="row">
                    <div class="col-sm-6">
                        Copyright &copy; 2020 Admin panel
                    </div>
                    <div class="col-sm-6 text-right">
                        Designed by <a href="https://alamindevbd.com">Al-amin</a>
                    </div>
                </div>
            </div>
        </footer>